# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_cinch_global_optspecs
	string join \n h/help V/version
end

function __fish_cinch_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_cinch_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_cinch_using_subcommand
	set -l cmd (__fish_cinch_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c cinch -n "__fish_cinch_needs_command" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_needs_command" -s V -l version -d 'Print version'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "push" -d 'Push stdin to your local clipboard'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "pull" -d 'Pull clipboard content to stdout'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "auth" -d 'Manage authentication'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "pair" -d 'Set up cinch on a remote machine via SSH'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "devices" -d 'List paired devices for this account'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "get" -d 'Print a single clip\'s content by ID prefix'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "list" -d 'List recent clips'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "search" -d 'Full-text search across the local clip store'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "pin" -d 'Pin a clip by ID prefix'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "pinned" -d 'List pinned clips'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "unpin" -d 'Unpin a clip by ID prefix'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "nickname" -d 'Set or clear a device\'s nickname'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "sources" -d 'List distinct source machines that have pushed clips'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "retention" -d 'View or set per-device clip retention'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "revoke" -d 'Revoke a paired device\'s token (asks for confirmation)'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "admin" -d 'Administer this relay (self-host operators only)'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "rm" -d 'Delete a clip by ID prefix (with TTY confirm unless --force)'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "telemetry" -d 'View or change anonymous usage telemetry state'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "completion" -d 'Print a shell completion script to stdout'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "self-update" -d 'Download and install the latest release (for manually-placed binaries)'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand push" -s l -l label -d 'Label for this clip' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l type -d 'Force content type. Accepts `image` or any `image/*` MIME to override the image-vs-text decision; text subtypes (text/url/code) are derived automatically by `client_core::classify::detect`' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l token -d 'Override auth token (or set CINCH_TOKEN env var)' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l relay -d 'Override relay URL (or set CINCH_RELAY_URL env var)' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l to -d 'Send only to the device with this nickname or hostname (resolved via GET /devices to a target_device_id). The relay rejects the push with `device_offline` if the resolved device is not currently connected' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -s s -l silent -d 'Suppress success output'
complete -c cinch -n "__fish_cinch_using_subcommand push" -l text -d 'Force text mode (skip binary detection)'
complete -c cinch -n "__fish_cinch_using_subcommand push" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l from -d 'Pull latest clip from a device by nickname or hostname' -r
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l id -d 'Fetch a specific clip by ID instead of "latest"' -r
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l raw -d 'Print to stdout only; do not write to the system clipboard'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l text-only -d 'Skip image clips, return latest text clip'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l copy -d 'Copy text content to system clipboard (TTY only). Ignored when --raw is set'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l exclude-self -d 'Exclude clips authored by the local device. Incompatible with --from and --id'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l watch -d 'Subscribe to live clip stream over WebSocket and print each clip to stdout as it arrives (one clip per line, prefixed with source). Combine with `--from <name>` to filter to a single source'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "login" -d 'Sign in to Cinch via browser (GitHub / Google)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "status" -d 'Show current auth state'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "logout" -d 'Remove stored credentials and revoke this device on the relay'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "approve" -d 'Approve a remote device-code login from this signed-in machine'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "retry-key" -d 'Ask another paired device to re-share the encryption key'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "set-name" -d 'Set your display name (overrides the OAuth-fetched name)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "recovery" -d 'Backup or restore the encryption key as a 24-word BIP39 phrase'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout approve retry-key set-name recovery help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l relay -d 'Override relay URL (skips the interactive relay-URL prompt)' -r
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l user -d 'Hint your account email so signed-in devices (Cinch.app) receive a push approval prompt instead of you having to copy the code by hand. Defaults to the email cached in ~/.cinch/config.json from a prior session, when present and the token is empty (re-login)' -r
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l force -d 'Force a fresh sign-in even when this machine is already authenticated. Without this flag, `cinch auth login` exits immediately if a valid token + matching machine_id is on disk'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l headless -d 'Headless mode: do not auto-open a browser. Emit a single-line stdout marker containing the device-code URL so an orchestrator (e.g. `cinch pair` over SSH) can pick it up programmatically. All other output goes to stderr'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from logout" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from approve" -l relay -d 'Override relay URL if the remote login is using a different relay' -r
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from approve" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from retry-key" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from set-name" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from recovery" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from recovery" -f -a "show" -d 'Print the encryption key as 24 BIP39 words. Record the phrase somewhere only you can reach (password manager, paper backup). Anyone with the phrase can decrypt your clipboard history'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from recovery" -f -a "restore" -d 'Restore the encryption key on this device from a 24-word phrase. Run after `cinch auth login` on a new machine. If a key is already stored, asks before overwriting'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from recovery" -f -a "verify" -d 'Check a 24-word phrase against the currently stored key without changing anything. Useful for verifying a backup before relying on it'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from recovery" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "login" -d 'Sign in to Cinch via browser (GitHub / Google)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show current auth state'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "logout" -d 'Remove stored credentials and revoke this device on the relay'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "approve" -d 'Approve a remote device-code login from this signed-in machine'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "retry-key" -d 'Ask another paired device to re-share the encryption key'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "set-name" -d 'Set your display name (overrides the OAuth-fetched name)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "recovery" -d 'Backup or restore the encryption key as a 24-word BIP39 phrase'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand pair" -l relay-url -d 'Override relay URL configured on the remote machine' -r
complete -c cinch -n "__fish_cinch_using_subcommand pair" -l skip-install -d 'Skip cinch binary installation on the remote (use if already installed)'
complete -c cinch -n "__fish_cinch_using_subcommand pair" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand devices" -l names -d 'Print one name per line (nickname or hostname), no header. Intended for shell completion. Silent on auth/network failure'
complete -c cinch -n "__fish_cinch_using_subcommand devices" -l paired-only -d 'Show only paired devices (legacy behavior). Default is the merged view'
complete -c cinch -n "__fish_cinch_using_subcommand devices" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand get" -l meta -d 'Print metadata only, not content'
complete -c cinch -n "__fish_cinch_using_subcommand get" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand list" -l limit -d 'Max number of clips to return. Hard cap is 200' -r
complete -c cinch -n "__fish_cinch_using_subcommand list" -l from -d 'Filter by source device (nickname or hostname)' -r
complete -c cinch -n "__fish_cinch_using_subcommand list" -l text-only -d 'Drop image clips'
complete -c cinch -n "__fish_cinch_using_subcommand list" -l exclude-self -d 'Drop clips authored by this device'
complete -c cinch -n "__fish_cinch_using_subcommand list" -l json -d 'Force JSON output (default when stdout is not a TTY)'
complete -c cinch -n "__fish_cinch_using_subcommand list" -l remote -d 'Bypass the local store and fetch directly from the relay'
complete -c cinch -n "__fish_cinch_using_subcommand list" -l pinned -d 'Show only pinned clips'
complete -c cinch -n "__fish_cinch_using_subcommand list" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand search" -l limit -d 'Max rows to return' -r
complete -c cinch -n "__fish_cinch_using_subcommand search" -l format -d '`text` (default) or `json`' -r
complete -c cinch -n "__fish_cinch_using_subcommand search" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand pin" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand pinned" -l limit -d 'Max number of clips to return. Hard cap is 200' -r
complete -c cinch -n "__fish_cinch_using_subcommand pinned" -l json -d 'Force JSON output (default when stdout is not a TTY)'
complete -c cinch -n "__fish_cinch_using_subcommand pinned" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand unpin" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand nickname" -l clear -d 'Clear the device\'s nickname'
complete -c cinch -n "__fish_cinch_using_subcommand nickname" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand sources" -l format -d '`text` (default) or `json`' -r
complete -c cinch -n "__fish_cinch_using_subcommand sources" -l names -d 'One name per line, no header'
complete -c cinch -n "__fish_cinch_using_subcommand sources" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand retention" -l device -d 'Device ID prefix or `self` for this device (read-only for non-self)' -r
complete -c cinch -n "__fish_cinch_using_subcommand retention" -l days -d 'New retention in days; omit to read the current value(s)' -r
complete -c cinch -n "__fish_cinch_using_subcommand retention" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand revoke" -l force -d 'Skip the TTY confirmation prompt'
complete -c cinch -n "__fish_cinch_using_subcommand revoke" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and not __fish_seen_subcommand_from invite user help" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and not __fish_seen_subcommand_from invite user help" -f -a "invite" -d 'Manage invite codes (self-host)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and not __fish_seen_subcommand_from invite user help" -f -a "user" -d 'Manage users (self-host)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and not __fish_seen_subcommand_from invite user help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from invite" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from invite" -f -a "create" -d 'Create a new invite code'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from invite" -f -a "list" -d 'List existing invite codes (shows hashes, never plaintext codes)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from invite" -f -a "revoke" -d 'Revoke an invite code by its full SHA-256 hash (from `list`)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from invite" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from user" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from user" -f -a "list" -d 'List all users registered on this relay'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from user" -f -a "remove" -d 'Remove a user by ID (cannot remove your own admin account)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from user" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from help" -f -a "invite" -d 'Manage invite codes (self-host)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from help" -f -a "user" -d 'Manage users (self-host)'
complete -c cinch -n "__fish_cinch_using_subcommand admin; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand rm" -l force -d 'Skip the TTY confirmation prompt'
complete -c cinch -n "__fish_cinch_using_subcommand rm" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and not __fish_seen_subcommand_from status on off help" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and not __fish_seen_subcommand_from status on off help" -f -a "status" -d 'Show current telemetry state and how it\'s configured'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and not __fish_seen_subcommand_from status on off help" -f -a "on" -d 'Enable telemetry on this machine (removes the opt-out file)'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and not __fish_seen_subcommand_from status on off help" -f -a "off" -d 'Disable telemetry on this machine (creates the opt-out file)'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and not __fish_seen_subcommand_from status on off help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from on" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from off" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show current telemetry state and how it\'s configured'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from help" -f -a "on" -d 'Enable telemetry on this machine (removes the opt-out file)'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from help" -f -a "off" -d 'Disable telemetry on this machine (creates the opt-out file)'
complete -c cinch -n "__fish_cinch_using_subcommand telemetry; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand completion" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cinch -n "__fish_cinch_using_subcommand self-update" -l check -d 'Print what would happen and exit without changing the binary'
complete -c cinch -n "__fish_cinch_using_subcommand self-update" -l force -d 'Override the refusal to clobber a package-manager-managed binary'
complete -c cinch -n "__fish_cinch_using_subcommand self-update" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "push" -d 'Push stdin to your local clipboard'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "pull" -d 'Pull clipboard content to stdout'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "auth" -d 'Manage authentication'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "pair" -d 'Set up cinch on a remote machine via SSH'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "devices" -d 'List paired devices for this account'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "get" -d 'Print a single clip\'s content by ID prefix'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "list" -d 'List recent clips'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "search" -d 'Full-text search across the local clip store'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "pin" -d 'Pin a clip by ID prefix'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "pinned" -d 'List pinned clips'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "unpin" -d 'Unpin a clip by ID prefix'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "nickname" -d 'Set or clear a device\'s nickname'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "sources" -d 'List distinct source machines that have pushed clips'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "retention" -d 'View or set per-device clip retention'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "revoke" -d 'Revoke a paired device\'s token (asks for confirmation)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "admin" -d 'Administer this relay (self-host operators only)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "rm" -d 'Delete a clip by ID prefix (with TTY confirm unless --force)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "telemetry" -d 'View or change anonymous usage telemetry state'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "completion" -d 'Print a shell completion script to stdout'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "self-update" -d 'Download and install the latest release (for manually-placed binaries)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair devices get list search pin pinned unpin nickname sources retention revoke admin rm telemetry completion self-update help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "login" -d 'Sign in to Cinch via browser (GitHub / Google)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "status" -d 'Show current auth state'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "logout" -d 'Remove stored credentials and revoke this device on the relay'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "approve" -d 'Approve a remote device-code login from this signed-in machine'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "retry-key" -d 'Ask another paired device to re-share the encryption key'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "set-name" -d 'Set your display name (overrides the OAuth-fetched name)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "recovery" -d 'Backup or restore the encryption key as a 24-word BIP39 phrase'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from admin" -f -a "invite" -d 'Manage invite codes (self-host)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from admin" -f -a "user" -d 'Manage users (self-host)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from telemetry" -f -a "status" -d 'Show current telemetry state and how it\'s configured'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from telemetry" -f -a "on" -d 'Enable telemetry on this machine (removes the opt-out file)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from telemetry" -f -a "off" -d 'Disable telemetry on this machine (creates the opt-out file)'

# cinch --from dynamic completion
complete -c cinch -n '__fish_seen_subcommand_from pull' -l from -f \
  -d 'Device nickname or hostname' \
  -a '(cinch devices --names 2>/dev/null)'
