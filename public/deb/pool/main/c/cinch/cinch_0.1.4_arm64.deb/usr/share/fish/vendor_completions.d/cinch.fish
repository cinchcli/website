# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_cinch_global_optspecs
	string join \n h/help V/version
end

function __fish_cinch_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_cinch_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_cinch_using_subcommand
	set -l cmd (__fish_cinch_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c cinch -n "__fish_cinch_needs_command" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_needs_command" -s V -l version -d 'Print version'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "push" -d 'Push stdin to your local clipboard'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "pull" -d 'Pull clipboard content to stdout'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "auth" -d 'Manage authentication'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "pair" -d 'Set up cinch on a remote machine via SSH'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "completion" -d 'Print a shell completion script to stdout'
complete -c cinch -n "__fish_cinch_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand push" -s l -l label -d 'Label for this clip' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l type -d 'Force MIME type (e.g. image/png)' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l token -d 'Override auth token (or set CINCH_TOKEN env var)' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l relay -d 'Override relay URL (or set CINCH_RELAY_URL env var)' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -l to -d 'Send only to the device with this nickname (resolves via /devices). Phase 4 wires this up; for now the flag parses but is rejected' -r
complete -c cinch -n "__fish_cinch_using_subcommand push" -s s -l silent -d 'Suppress success output'
complete -c cinch -n "__fish_cinch_using_subcommand push" -l text -d 'Force text mode (skip binary detection)'
complete -c cinch -n "__fish_cinch_using_subcommand push" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l from -d 'Pull latest clip from a device by nickname or hostname' -r
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l text-only -d 'Skip image clips, return latest text clip'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l copy -d 'Copy text content to system clipboard (TTY only)'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -l watch -d 'Subscribe to live clip stream over WebSocket and print each clip to stdout as it arrives (one clip per line, prefixed with source). Combine with `--from <name>` to filter to a single source'
complete -c cinch -n "__fish_cinch_using_subcommand pull" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "login" -d 'Sign in to Cinch via browser (GitHub / Google)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "status" -d 'Show current auth state'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "logout" -d 'Remove stored credentials and revoke this device on the relay'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "device-code" -d 'Sign in via device code (for headless / SSH environments)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "approve" -d 'Approve a remote device-code login from this signed-in machine'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "retry-key" -d 'Ask another paired device to re-share the encryption key'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and not __fish_seen_subcommand_from login status logout device-code approve retry-key help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l relay -d 'Override relay URL (skips the interactive relay-URL prompt)' -r
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l force -d 'Force a fresh sign-in even when this machine is already authenticated. Without this flag, `cinch auth login` exits immediately if a valid token + matching machine_id is on disk'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -l headless -d 'Headless mode: do not auto-open a browser. Emit a single-line stdout marker containing the device-code URL so an orchestrator (e.g. `cinch pair` over SSH) can pick it up programmatically. All other output goes to stderr'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from login" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from logout" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from device-code" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from approve" -l relay -d 'Override relay URL if the remote login is using a different relay' -r
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from approve" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from retry-key" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "login" -d 'Sign in to Cinch via browser (GitHub / Google)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show current auth state'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "logout" -d 'Remove stored credentials and revoke this device on the relay'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "device-code" -d 'Sign in via device code (for headless / SSH environments)'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "approve" -d 'Approve a remote device-code login from this signed-in machine'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "retry-key" -d 'Ask another paired device to re-share the encryption key'
complete -c cinch -n "__fish_cinch_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand pair" -l relay-url -d 'Override relay URL configured on the remote machine' -r
complete -c cinch -n "__fish_cinch_using_subcommand pair" -l skip-install -d 'Skip cinch binary installation on the remote (use if already installed)'
complete -c cinch -n "__fish_cinch_using_subcommand pair" -s h -l help -d 'Print help'
complete -c cinch -n "__fish_cinch_using_subcommand completion" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair completion help" -f -a "push" -d 'Push stdin to your local clipboard'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair completion help" -f -a "pull" -d 'Pull clipboard content to stdout'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair completion help" -f -a "auth" -d 'Manage authentication'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair completion help" -f -a "pair" -d 'Set up cinch on a remote machine via SSH'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair completion help" -f -a "completion" -d 'Print a shell completion script to stdout'
complete -c cinch -n "__fish_cinch_using_subcommand help; and not __fish_seen_subcommand_from push pull auth pair completion help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "login" -d 'Sign in to Cinch via browser (GitHub / Google)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "status" -d 'Show current auth state'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "logout" -d 'Remove stored credentials and revoke this device on the relay'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "device-code" -d 'Sign in via device code (for headless / SSH environments)'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "approve" -d 'Approve a remote device-code login from this signed-in machine'
complete -c cinch -n "__fish_cinch_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "retry-key" -d 'Ask another paired device to re-share the encryption key'
